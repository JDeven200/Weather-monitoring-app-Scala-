import Classes.dataMap

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

class FunctionApplication {

  val read = new FileReader
  val dataMap = read.readFromFile()
  val func = new Functions

  def getDataMap() :Map[String, List[(Int, Int)]] = {
    return dataMap
  }

  def checkCity(city: String): Boolean = {
    var check:Boolean = false
    for(map <- dataMap.keys) {
      if (map.equals(city))
      {
        check = true
        return check
      }
    }
    check
  }

  def setCityKeys():List[(String)] = {
    val cities = dataMap.keys.toList
    cities
  }

  def setCityVals():List[List[(Int, Int)]] = {
    val temps = dataMap.values.toList
    temps
  }
  def getMinMaxTempDifference(keys: List[(String)], values: List[List[(Int, Int)]]):Map[String,List[(Int)]] = {
    var minMaxDiff = List(0)
    var minMaxDiffBuffer = new ListBuffer[List[(Int)]]
    def calculate(y: List[List[(Int, Int)]]) = {
      for (temp <- y) {
        val lowestTemp = temp.map(_._1)
        val highestTemp = temp.map(_._2)
        val diffList = func.difference(highestTemp, lowestTemp)
        minMaxDiff = diffList
        minMaxDiffBuffer.+=(minMaxDiff)
      }
    }
    calculate(values)
    val minMaxList = minMaxDiffBuffer.toList
    keys zip minMaxList toMap
  }

  def getMostRecentTempAllCities(keys: List[(String)], values: List[List[(Int, Int)]]):Map[String,(Int, Int)] = {
    var mostRecentTemps =(0,0)
    var mostRecentTempsBuffer = new ListBuffer[(Int, Int)]()
    def calculate(y: List[List[(Int, Int)]])  = {
      for(temp <- y) {
        mostRecentTemps = func.mostRecent(temp)
        mostRecentTempsBuffer += mostRecentTemps
      }
    }
    calculate(values)
    val mostRecentTempsList = mostRecentTempsBuffer.toList
    keys zip mostRecentTempsList toMap
  }

  def getItinerary(city:String, f:String => Boolean): Map[String, Any] = {
    if(f(city)) {
      val tempList = dataMap(city)
      val lowestTemps = tempList.map(_._1)
      val highestTemps = tempList.map(_._2)
      val highestAverageTemps = func.mean(highestTemps)
      val lowestAverageTemps = func.mean(lowestTemps)
      val mostRecentTemps = func.mostRecent(tempList)
      val cityName = Map("City" -> city)
      val highestAverageTempsMap = Map("Highest average Temperature" -> highestAverageTemps)
      val lowestAverageTempsMap = Map("Lowest average Temperature" -> lowestAverageTemps)
      val mostRecentTempsMap = Map("Lowest and highest temperature last year" -> mostRecentTemps)
      var cityInfo: Map[String, Any] = Map()
      cityInfo = cityInfo ++ cityName ++ mostRecentTempsMap ++ lowestAverageTempsMap ++ highestAverageTempsMap
      cityInfo
    }
    else{
      val emptyList = ("There doesn't seem to be any info...")
      val emptyMap = Map(city -> emptyList)
      emptyMap
    }
  }

  def printItinerary(cityMap: Map[String, Any]) = {
    cityMap foreach {
      case (k, v) => println(s"$k: $v")
    }
  }

  def getMeanTemp(keys: List[(String)], values: List[List[(Int, Int)]]):Map[String, Double] = {
    var tempsMean = (0.0)
    var tempsMeanBuffer = new ListBuffer[(Double)]
    def calculate(y: List[List[(Int, Int)]]) = {
      for (temp <- y){
        val lowestTemps = temp.map(_._1)
        val highestTemps = temp.map(_._2)
        val diffList = func.difference(highestTemps, lowestTemps)
        val meanVal = func.mean(diffList)
        tempsMean = meanVal
        tempsMeanBuffer += tempsMean
      }
    }
    calculate(values)
    val tempsMeanList = tempsMeanBuffer.toList
    keys zip tempsMeanList toMap
  }

  def getGreatestDifference(keys: List[(String)], values: List[List[(Int, Int)]]):Map[String, List[(Int)]] = {
    var greatestDiff = List(0)
    var greatestDiffBuffer = new ListBuffer[List[(Int)]]
    def calculate(y: List[List[(Int, Int)]]) = {
      for(temp <- y){
        val lowestTemp = temp.map(_._1)
        val highestTemp = temp.map(_._2)
        val diffList = func.greatestDifference(highestTemp, lowestTemp)
        greatestDiff = diffList
        greatestDiffBuffer += greatestDiff
      }
    }
    calculate(values)
    val greatestDiffList = greatestDiffBuffer.toList
    keys zip greatestDiffList toMap
  }

  def printMostRecentTemps() ={
    val dataMap = getMostRecentTempAllCities(setCityKeys(), setCityVals())
    for((k, v) <- dataMap) {
    println(s"$k: $v")
    }
  }

  def printMinMaxTempDiff() = {
    val dataMap = getMinMaxTempDifference(setCityKeys(), setCityVals())
    for((k, v) <- dataMap) {
      println(s"$k: $v")
    }
  }

  def printMeanTemp() = {
    val dataMap = getMeanTemp(setCityKeys(), setCityVals())
    for((k, v) <- dataMap) {
      println(s"$k: $v")
    }
  }

  def printGreatestTempDifference() = {
    val dataMap = getGreatestDifference(setCityKeys(), setCityVals())
    for((k, v) <- dataMap) {
      println(s"$k: $v")
    }
  }

  def userMenu() ={
    println("1: Most recent temperatures (lowest, highest) for each city")
    println("2: Difference between lowest and highest temperatures for each city")
    println("3: Mean of the difference between lowest and highest temperatures for each city")
    println("4: Greatest total difference between lowest and highest temperatures for each city")
    println("5: Create itinerary")
    println("6: Exit")
  }

  def createItinerary() = {
    var buffer = new ArrayBuffer[Any]
    println("Enter each city, separated with a comma: ")
    val input = scala.io.StdIn.readLine()
    val split = input.trim.split(",")
    buffer = buffer ++ split
    val bufferList = buffer.toList
    println(bufferList)
    for(x <- bufferList) {
      val city:String = x.toString
      printItinerary(getItinerary(city, checkCity))
    }

  }
}

import scala.collection.mutable.ArrayBuffer
import scala.io.Source

class FileReader {

  def readFromFile() = {
    val file = Source.fromFile("/Users/jidev/Documents/Uni/3rd Year/weatherdata14March.txt")
    var buffer = new ArrayBuffer[String]()
    for (line <- file.getLines) {
      val lineString = line.mkString
      val split = lineString.split(",")
      buffer = buffer ++ split
    }
    file.close()
    getMap(buffer)
  }

  def getMap(buff: ArrayBuffer[String]) :Map[String, List[(Int, Int)]] = {
    val key1 = buff(0)
    val key2 = buff(10)
    val key3 = buff(20)
    val key4 = buff(30)
    val key5 = buff(40)
    val key6 = buff(50)
    val key7 = buff(60)
    val key8 = buff(70)
    val key9 = buff(80)
    val key10 = buff(90)
    var fullList:List[(Int, Int)] = List()
    var b = 1
    var newBuff = new ArrayBuffer[String]()
    var intBuff = new ArrayBuffer[(Int, Int)]()
    var mapBuffer: Map[String, List[(Int, Int)]] = Map()
    for(x <- buff) {
      val split = x.split(":")
      newBuff = newBuff ++ split
    }
    for(a <- b until 101) {
      try {
        val num = (newBuff(b).toInt, newBuff(b+1).toInt)
        b+=2
        intBuff = intBuff += num
      }
      catch {
        case e: Exception =>
          fullList = intBuff.toList
          b+=1
      }
    }
    val splitList = fullList.grouped(9).toList
    val val1 = splitList(0)
    val val2 = splitList(1)
    val val3 = splitList(2)
    val val4 = splitList(3)
    val val5 = splitList(4)
    val val6 = splitList(5)
    val val7 = splitList(6)
    val val8 = splitList(7)
    val val9 = splitList(8)
    val val10 = splitList(9)
    mapBuffer = mapBuffer ++ Map(key1 -> val1)
    mapBuffer = mapBuffer ++ Map(key2 -> val2)
    mapBuffer = mapBuffer ++ Map(key3 -> val3)
    mapBuffer = mapBuffer ++ Map(key4 -> val4)
    mapBuffer = mapBuffer ++ Map(key5 -> val5)
    mapBuffer = mapBuffer ++ Map(key6 -> val6)
    mapBuffer = mapBuffer ++ Map(key7 -> val7)
    mapBuffer = mapBuffer ++ Map(key8 -> val8)
    mapBuffer = mapBuffer ++ Map(key9 -> val9)
    mapBuffer = mapBuffer ++ Map(key10 -> val10)
    mapBuffer
  }

}

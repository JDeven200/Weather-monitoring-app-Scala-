class Functions {

  def difference(maxList : List[(Int)], minList : List[Int]):List[(Int)] = {
    val diff = (maxList, minList).zipped.map(_-_)
    diff
  }

  def mean(diffList : List[(Int)]): Double = {
    val mean = diffList.sum/diffList.size.toDouble
    mean
  }

  def greatestDifference(maxList: List[(Int)], minList : List[(Int)]): List[(Int)] = {
    val greatestMax = maxList.max
    val smallestMin = minList.min
    val greatestDiff = List(smallestMin.toInt, greatestMax.toInt)
    greatestDiff
  }

  def mostRecent(tempList: List[(Int, Int)]): (Int, Int) = tempList match {
    case Nil => null
    case x :: Nil => x
    case _ :: y => mostRecent(y)
  }
}

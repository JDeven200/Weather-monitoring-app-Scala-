object Classes{

  val funcApp = new FunctionApplication
  val dataMap:Map[String, List[(Int, Int)]] = funcApp.getDataMap()

  def main(args: Array[String]): Unit = {
    //funcApp.createItinerary()
    //for((k, v) <- dataMap) {
      //println(s"$k: $v")
    //}
    var input = ""
    do{
      funcApp.userMenu()
      println("Enter your selection: ")
      input = scala.io.StdIn.readLine()
      input match {
        case "1" => funcApp.printMostRecentTemps()
        case "2" => funcApp.printMinMaxTempDiff()
        case "3" => funcApp.printMeanTemp()
        case "4" => funcApp.printGreatestTempDifference()
        case "5" => funcApp.createItinerary()
        case "6" => return
        case _ => println("Not a valid option")
      }
    }while(!input.equals("6"))
  }

}
